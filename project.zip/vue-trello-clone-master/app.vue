<template>
  <div class="p-10 h-[100vh] bg-teal-600 overflow-auto">
    <Header />
    <TrelloBoard />
  </div>
</template>
