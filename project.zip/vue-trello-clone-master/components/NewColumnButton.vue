<template>
  <button class="new-button">
    <font-awesome-icon icon="fa-solid fa-plus" />
    Add a new column
  </button>
</template>

<style lang="css">
  .new-button {
    @apply text-gray-600 bg-gray-200 hover:bg-gray-300 whitespace-nowrap px-4 py-2 rounded transition-all duration-150 ease-out;
  }
</style>